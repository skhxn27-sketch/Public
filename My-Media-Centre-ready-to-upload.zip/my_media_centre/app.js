const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
let media=JSON.parse(localStorage.getItem("mmc-media")||"null")||[
 {id:1,title:"Demo: Big Buck Bunny",type:"Movies",icon:"🎬",desc:"A sample public-domain style demo slot. Add your own video to play it.",progress:62},
 {id:2,title:"Your First Show",type:"TV Shows",icon:"📺",desc:"Add your own episodes using the Add media button.",progress:28},
 {id:3,title:"My Favourite",type:"Movies",icon:"⭐",desc:"A placeholder for your personal library.",progress:0},
 {id:4,title:"Family Videos",type:"TV Shows",icon:"🏠",desc:"Your private family media collection.",progress:0}
];
let list=JSON.parse(localStorage.getItem("mmc-list")||"[]");
const save=()=>{localStorage.setItem("mmc-media",JSON.stringify(media));localStorage.setItem("mmc-list",JSON.stringify(list))};
function render(section="home",query=""){
 let items=media.filter(x=>!query||x.title.toLowerCase().includes(query.toLowerCase()));
 if(section==="movies")items=items.filter(x=>x.type==="Movies");
 if(section==="shows")items=items.filter(x=>x.type==="TV Shows");
 if(section==="watchlist")items=items.filter(x=>list.includes(x.id));
 if(section==="home")items=items.sort((a,b)=>b.progress-a.progress);
 $("#sectionTitle").textContent=section==="home"?"Continue Watching":section==="watchlist"?"My List":section==="movies"?"Movies":"TV Shows";
 $("#grid").innerHTML=items.map(card).join("")||`<p style="color:#999">Nothing here yet. Add your own media.</p>`;
 $$("#grid .card").forEach(c=>c.onclick=()=>play(+c.dataset.id));
}
function card(x){return `<article class="card" data-id="${x.id}"><div class="poster">${x.icon||"🎞️"}</div><div class="card-body"><h3>${x.title}</h3><p>${x.type}</p></div>${x.progress?`<div class="progress"><i style="width:${x.progress}%"></i></div>`:""}</article>`}
function play(id){
 const x=media.find(m=>m.id===id); if(!x)return;
 $("#playerTitle").textContent=x.title;$("#playerDesc").textContent=x.desc||"";
 $("#playerPanel").classList.remove("hidden");
 const v=$("#player"); v.pause();v.removeAttribute("src");
 if(x.url){v.src=x.url;v.play().catch(()=>{})}
}
$$(".nav").forEach(b=>b.onclick=()=>{$$(".nav").forEach(n=>n.classList.remove("active"));b.classList.add("active");render(b.dataset.section)});
$$("[data-close]").forEach(b=>b.onclick=()=>b.closest(".overlay").classList.add("hidden"));
$("#searchBtn").onclick=()=>{$("#searchPanel").classList.remove("hidden");$("#searchInput").focus()};
$("#searchInput").oninput=e=>{$("#searchResults").innerHTML=media.filter(x=>x.title.toLowerCase().includes(e.target.value.toLowerCase())).map(card).join("");$$("#searchResults .card").forEach(c=>c.onclick=()=>play(+c.dataset.id))};
$("#settingsBtn").onclick=()=>$("#settingsPanel").classList.remove("hidden");
$("#saveSettings").onclick=()=>{document.documentElement.style.setProperty("--accent",$("#accent").value);document.title=$("#siteName").value;$("#settingsPanel").classList.add("hidden")};
$("#addMedia").onclick=()=>$("#filePicker").click();
$("#filePicker").onchange=e=>[...e.target.files].forEach(file=>{const url=URL.createObjectURL(file);media.push({id:Date.now()+Math.random(),title:file.name.replace(/\.[^.]+$/,""),type:file.type.startsWith("video")?"Movies":"Audio",icon:file.type.startsWith("video")?"🎬":"🎵",url,desc:"Local media file",progress:0});save();render()});
$("#demoPlay").onclick=()=>play(1);
$("#heroList").onclick=()=>{if(!list.includes(1))list.push(1);save();render("watchlist")};
render();
