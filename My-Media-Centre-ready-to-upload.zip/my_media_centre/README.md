# My Media Centre

A lightweight, personal-use, CloudStream-inspired media-centre interface.

## Quick start

1. Extract the ZIP.
2. Open `index.html` in a browser.
3. Use **Add media** to select your own local video/audio files.
4. Your library/watchlist is stored in browser local storage.

## Hosting

This is a static site, so it can be uploaded to any static web host. Upload:
- `index.html`
- `styles.css`
- `app.js`
- the `assets` folder

## Important

The site intentionally does not include third-party copyrighted streaming sources or piracy extensions. CloudStream itself says its base app does not provide video sources by default and warns against extensions hosting copyrighted media. See the original project for its licensing and source.

## Next upgrade

For a real multi-device private library, add a backend/media server such as Jellyfin or a private object-storage/CDN setup. Then the player can use authenticated streaming URLs instead of browser-local files.
